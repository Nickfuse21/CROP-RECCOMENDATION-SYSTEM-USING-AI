# CropReccomendationSystem
🌱 Crop Recommendation System A machine learning tool that suggests the most suitable crop based on soil nutrients (N, P, K), temperature, humidity, pH, and rainfall. Built with Python and Scikit-learn to help farmers make data-driven, yield-optimizing decisions.
